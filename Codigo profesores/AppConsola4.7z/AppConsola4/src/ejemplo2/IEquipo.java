package ejemplo2;

public interface IEquipo {

	public String devuelveInformacion();
}
