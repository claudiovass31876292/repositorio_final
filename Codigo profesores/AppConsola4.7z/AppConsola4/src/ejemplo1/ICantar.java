package ejemplo1;

public interface ICantar {
	
	//M�todos abstractos
	
	public void cantar();

	//Atributos publicos, constantes y est�ticos
	
	//public final static int var=8;
	
	//int var2=9;
	
	
}
