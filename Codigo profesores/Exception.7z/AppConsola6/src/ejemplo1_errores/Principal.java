package ejemplo1_errores;

public class Principal {

	public static void main(String[] args) {
		
		// Errores en tiempo de compilaci�n (Errores de sintaxis)
		
		//String nombre;
		//nombre = 888889;
		
		
		//Errores en tiempo de ejecuci�n
		
		int num1 = 9;
		int num2 = 0;
		
		int res= num1 / num2 ;
		
		//EXCEPCIONES SON ERRORES EN TIEMPO DE EJECUCI�N
		
	}

}
